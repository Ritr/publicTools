执行exe或ahk文件，然后按鼠标中键（按滚轮，不是滚动它）

Execute the exe or ahk file, then press the middle mouse button (press the scroll wheel, not scroll it)
